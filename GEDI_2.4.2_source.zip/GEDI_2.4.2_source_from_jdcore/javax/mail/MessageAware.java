package javax.mail;

public interface MessageAware
{
  public abstract MessageContext getMessageContext();
}
