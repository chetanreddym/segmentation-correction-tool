package javax.mail;














public class MethodNotSupportedException
  extends MessagingException
{
  public MethodNotSupportedException() {}
  












  public MethodNotSupportedException(String paramString)
  {
    super(paramString);
  }
}
