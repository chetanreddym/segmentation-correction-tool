package javax.mail.internet;

import javax.mail.MessagingException;

























public class ParseException
  extends MessagingException
{
  public ParseException() {}
  
  public ParseException(String paramString)
  {
    super(paramString);
  }
}
