package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;

















public final class MosaicType
  extends EnumeratedParameter
{
  MosaicType(String name, int value)
  {
    super(name, value);
  }
}
