package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;



















public final class MaxFilterShape
  extends EnumeratedParameter
{
  MaxFilterShape(String name, int value)
  {
    super(name, value);
  }
}
