package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;


















public final class ShearDir
  extends EnumeratedParameter
{
  ShearDir(String name, int value)
  {
    super(name, value);
  }
}
