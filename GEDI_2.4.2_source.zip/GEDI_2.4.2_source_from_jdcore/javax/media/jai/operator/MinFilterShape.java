package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;



















public final class MinFilterShape
  extends EnumeratedParameter
{
  MinFilterShape(String name, int value)
  {
    super(name, value);
  }
}
