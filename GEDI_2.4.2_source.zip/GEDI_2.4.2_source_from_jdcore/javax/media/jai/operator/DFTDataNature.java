package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;



















public final class DFTDataNature
  extends EnumeratedParameter
{
  DFTDataNature(String name, int value)
  {
    super(name, value);
  }
}
