package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;


















public final class DFTScalingType
  extends EnumeratedParameter
{
  DFTScalingType(String name, int value)
  {
    super(name, value);
  }
}
