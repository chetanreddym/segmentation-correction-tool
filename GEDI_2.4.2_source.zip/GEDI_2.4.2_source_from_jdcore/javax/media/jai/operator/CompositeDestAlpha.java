package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;



















public final class CompositeDestAlpha
  extends EnumeratedParameter
{
  CompositeDestAlpha(String name, int value)
  {
    super(name, value);
  }
}
