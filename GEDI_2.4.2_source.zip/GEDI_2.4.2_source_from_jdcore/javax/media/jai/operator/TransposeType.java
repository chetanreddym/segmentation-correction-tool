package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;




















public final class TransposeType
  extends EnumeratedParameter
{
  TransposeType(String name, int value)
  {
    super(name, value);
  }
}
