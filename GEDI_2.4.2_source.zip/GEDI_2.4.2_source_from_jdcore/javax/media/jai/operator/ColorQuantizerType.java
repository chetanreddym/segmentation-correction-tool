package javax.media.jai.operator;

import javax.media.jai.EnumeratedParameter;






















public final class ColorQuantizerType
  extends EnumeratedParameter
{
  ColorQuantizerType(String name, int value)
  {
    super(name, value);
  }
}
