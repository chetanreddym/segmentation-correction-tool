package javax.media.jai.widget;

/**
 * @deprecated
 */
public abstract interface ViewportListener
{
  public abstract void setViewport(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}
