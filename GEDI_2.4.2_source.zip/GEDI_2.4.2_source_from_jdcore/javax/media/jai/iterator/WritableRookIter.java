package javax.media.jai.iterator;

public abstract interface WritableRookIter
  extends RookIter, WritableRectIter
{}
