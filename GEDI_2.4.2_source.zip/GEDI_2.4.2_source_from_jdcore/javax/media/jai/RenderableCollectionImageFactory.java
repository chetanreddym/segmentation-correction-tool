package javax.media.jai;

import java.awt.image.renderable.ParameterBlock;

public abstract interface RenderableCollectionImageFactory
{
  public abstract CollectionImage create(ParameterBlock paramParameterBlock);
}
