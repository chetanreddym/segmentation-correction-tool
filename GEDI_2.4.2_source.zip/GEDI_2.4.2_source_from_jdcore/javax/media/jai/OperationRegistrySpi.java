package javax.media.jai;

public abstract interface OperationRegistrySpi
{
  public abstract void updateRegistry(OperationRegistry paramOperationRegistry);
}
