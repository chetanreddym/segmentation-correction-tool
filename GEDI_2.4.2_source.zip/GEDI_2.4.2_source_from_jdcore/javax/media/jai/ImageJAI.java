package javax.media.jai;

public abstract interface ImageJAI
  extends WritablePropertySource
{}
