package javax.media.jai;

import java.io.Serializable;










class ParameterNoDefault
  implements Serializable
{
  ParameterNoDefault() {}
  
  public String toString()
  {
    return "No Parameter Default";
  }
}
