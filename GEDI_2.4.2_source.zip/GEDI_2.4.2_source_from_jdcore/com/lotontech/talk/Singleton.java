package com.lotontech.talk;

public class Singleton
{
  public static int instances = 0;
  
  public Singleton() {}
}
