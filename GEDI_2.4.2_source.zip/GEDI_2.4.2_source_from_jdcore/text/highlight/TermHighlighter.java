package text.highlight;

public abstract interface TermHighlighter
{
  public abstract String highlightTerm(String paramString);
}
